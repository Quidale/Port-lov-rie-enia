<?php
session_start();
if(!isset($_SESSION['login'])) {
    header("Location: login.php");
}

include_once "../lib/DB.php";

use lugx_gaming\Lib\DB;

$db = new DB("localhost", 3306, "root", "", "lugxdb");

if(!isset($_GET['id'])) {
    header("Location: home.php");
}

$item = $db->getItemID($_GET['id']);
?>
<br><br>
<form action="update-item.php" method="post">
    <input type="text" name="multitags" value="<?php echo $item['multitags']; ?>" placeholder="Multi tagy"><br>
    <input type="text" name="genre" value="<?php echo $item['genre']; ?>" placeholder="Zaner"><br>
    <input type="text" name="gameid" value="<?php echo $item['gameid']; ?>" placeholder="ID hry"><br>
    <input type="text" name="desc" value="<?php echo $item['desc']; ?>" placeholder="Popis"><br>
    <input type="text" name="price" value="<?php echo $item['price']; ?>" placeholder="Cena"><br>
    <input type="text" name="img" value="<?php echo $item['img']; ?>" placeholder="Obrazok"><br>
    <input type="text" name="url" value="<?php echo $item['name']; ?>" placeholder="Meno"><br>
    <input type="hidden" name="id" value="<?php echo $item['id']; ?>">
    <input type="submit" name="submit" value="Aktualizovat">
</form>