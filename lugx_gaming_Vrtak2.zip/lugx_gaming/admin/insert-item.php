<?php
session_start();
if(!isset($_SESSION['login'])) {
    header("Location: login.php");
}

include_once "../lib/DB.php";

use lugx_gaming\Lib\DB;

$db = new DB("localhost", 3306, "root", "", "lugxdb");

//$_GET, $_POST, $_SESSION,$_COOKIE, $_SERVER, $_REQUEST, $_ENV, $_FILE
if(isset($_POST['submit'])) {
    $insert = $db->insertItem($_POST['name'], $_POST['img'], $_POST['price'], $_POST['desc'], $_POST['gameid'], $_POST['genre'], $_POST['multitags']);

    if($insert) {
        header("Location: home.php?status=1");
    } else {
        header("Location: home.php?status=2");
    }
} else {
    header("Location: home.php");
}