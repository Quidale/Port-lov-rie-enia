<?php
session_start();
if(!isset($_SESSION['login'])) {
    header("Location: login.php");
}

include_once "../lib/DB.php";

use lugx_gaming\Lib\DB;

$db = new DB("localhost", 3306, "root", "", "lugxdb");

$items = $db->getItems();

if(isset($_GET['status'])) {
    if($_GET['status'] == 1) {
        echo "<br><p style='color: green'>Hra vlozena korektne</p><br>";
    } elseif ($_GET['status'] == 2) {
        echo "<br><p style='color: red'>Hra nebola vlozena korektne</p><br>";
    } elseif ($_GET['status'] == 3) {
        echo "<br><p style='color: green'>Hra bola vymazana korektne</p><br>";
    } elseif ($_GET['status'] == 4) {
        echo "<br><p style='color: red'>Hra nebola vymazana korektne</p><br>";
    } elseif ($_GET['status'] == 5) {
        echo "<br><p style='color: green'>Hra bola aktualizovana korektne</p><br>";
    } elseif ($_GET['status'] == 6) {
        echo "<br><p style='color: red'>Hra nebola aktualizovana korektne</p><br>";
    }
}


echo "<ul>";
foreach ($items as $item) {
    echo "<li>".$item['page_name']." 
    <a href='update.php?id=".$item['id']."'>Update</a>  
    <a href='delete.php?id=".$item['id']."'>Delete</a>
    </li>";
}
echo "</ul>";
?>



