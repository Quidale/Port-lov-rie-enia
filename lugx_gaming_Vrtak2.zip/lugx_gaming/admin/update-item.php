<?php
session_start();
if(!isset($_SESSION['login'])) {
    header("Location: login.php");
}

include_once "../lib/DB.php";

use lugx_gaming\Lib\DB;

$db = new DB("localhost", 3306, "root", "", "lugxdb");

if(isset($_POST['submit'])) {
    $udpate = $db->updateItem($_POST['name'], $_POST['img'], $_POST['price'], $_POST['desc'], $_POST['gameid'], $_POST['genre'], $_POST['multitags']);

    if($udpate) {
        header("Location: home.php?status=5");
    } else {
        header("Location: home.php?status=6");
    }
} else {
    header("Location: home.php");
}