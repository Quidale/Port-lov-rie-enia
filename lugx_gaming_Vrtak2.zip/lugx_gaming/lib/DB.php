<?php

namespace lugx_gaming\Lib;

class DB
{
    private $host = "localhost";
    private $port = 3306;
    private $username = "root";
    private $password = "";
    private $dbName = "lugxdb";

    private \PDO $connection;

    public function __construct(
        string $host = "",
        int $port = 3306,
        string $username = "",
        string $password = "",
        string $dbName = ""
    )
    {
        if(!empty($host)) {
            $this->host = $host;
        }

        if(!empty($port)) {
            $this->port = $port;
        }

        if(!empty($username)) {
            $this->username = $username;
        }

        if(!empty($password)) {
            $this->password = $password;
        }

        if(!empty($dbName)) {
            $this->dbName = $dbName;
        }

        try {
            $this->connection = new \PDO(
                "mysql:host=$this->host;dbname=$this->dbName;charset=utf8mb4",
                $this->username,
                $this->password
            );
            // set the PDO error mode to exception
            $this->connection->setAttribute(\PDO::ATTR_ERRMODE, \PDO::ERRMODE_EXCEPTION);
        } catch(\PDOException $e) {
            echo "Connection failed: " . $e->getMessage();
        }
    }

    public function getItems(): array
    {
        $sql = "SELECT name, img, price, descr, gameid, genre, multitags FROM game";
        $query = $this->connection->query($sql);
        $data = $query->fetchAll(\PDO::FETCH_ASSOC);

        return $data;
    }

    public function getItemID(int $id): array
    {
        $sql = "SELECT * FROM game WHERE id = ".$id;
        $query = $this->connection->query($sql);
        $data = $query->fetch(\PDO::FETCH_ASSOC);

        return $data;
    }

    public function insertItem(string $name, string $img, int $price, string $desc, string $gameid, string $genre, string $multitags): bool
    {
        $sql = "INSERT INTO game(name, img, price, descr, gameid, genre, multitags) VALUE ('" . $name . "', '" . $img . "', '" . $price . "', '" . $desc . "', '" . $gameid . "', '" . $genre . "', '" . $multitags . "')";
        $stmt = $this->connection->prepare($sql);
        return $stmt->execute();
    }

    public function deleteItem(int $id): bool
    {
        $sql = "DELETE FROM game WHERE id = ".$id;
        $stmt = $this->connection->prepare($sql);
        return $stmt->execute();
    }

    public function updateItem(int $id, string $name = "", string $img = "", string $price = "", string $desc = "", string $gameid = "", string $genre = "", string $multitags = ""): bool
    {
        $sql = "UPDATE game SET ";

        if(!empty($name)) {
            $sql .= " page_name = '" . $name . "'";
        }

        if(!empty($img)) {
            $sql .= ", url = '" . $img . "'";
        }

        if(!empty($price)) {
            $sql .= ", url = '" . $price . "'";
        }

        if(!empty($desc)) {
            $sql .= ", url = '" . $desc . "'";
        }

        if(!empty($gameid)) {
            $sql .= ", url = '" . $gameid . "'";
        }

        if(!empty($genre)) {
            $sql .= ", url = '" . $genre . "'";
        }

        if(!empty($multitags)) {
            $sql .= ", url = '" . $multitags . "'";
        }

        $sql .= " WHERE id = ". $id;

        $stmt = $this->connection->prepare($sql);
        return $stmt->execute();
    }
}