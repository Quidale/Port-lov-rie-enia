-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Hostiteľ: 127.0.0.1
-- Čas generovania: Po 18.Dec 2023, 10:59
-- Verzia serveru: 10.4.28-MariaDB
-- Verzia PHP: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Databáza: `lugxdb`
--

-- --------------------------------------------------------

--
-- Štruktúra tabuľky pre tabuľku `game`
--

CREATE TABLE `game` (
  `id` int(32) NOT NULL,
  `name` text NOT NULL,
  `img` text NOT NULL,
  `price` int(32) NOT NULL,
  `descr` text NOT NULL,
  `gameid` text NOT NULL,
  `genre` text NOT NULL,
  `multitags` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_slovak_ci;

--
-- Sťahujem dáta pre tabuľku `game`
--

INSERT INTO `game` (`id`, `name`, `img`, `price`, `descr`, `gameid`, `genre`, `multitags`) VALUES
(1, 'Fallout', 'http://getwallpapers.com/wallpaper/full/a/2/c/82575.jpg', 29, 'Fallout is a media franchise of post-apocalyptic role-playing video games—and later action role-playing games—created by Tim Cain,[2] at Interplay Entertainment. The series is set during the 21st, 22nd and 23rd centuries, and its atompunk retrofuturistic setting and art work are influenced by the post-war culture of 1950s United States, with its combination of hope for the promises of technology and the lurking fear of nuclear annihilation. ', '', 'Adventure', ''),
(2, 'Half-Life', 'https://cdn.wccftech.com/wp-content/uploads/2017/07/half_life_1.jpg', 19, 'Half-Life is a 1998 first-person shooter game developed by Valve Corporation and published by Sierra Studios for Windows. It was Valve\'s debut product and the first game in the Half-Life series.', '', 'First-Person-Shooter', '');

-- --------------------------------------------------------

--
-- Štruktúra tabuľky pre tabuľku `menu`
--

CREATE TABLE `menu` (
  `id` int(32) NOT NULL,
  `page_name` text NOT NULL,
  `url` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_slovak_ci;

-- --------------------------------------------------------

--
-- Štruktúra tabuľky pre tabuľku `review`
--

CREATE TABLE `review` (
  `id` int(32) NOT NULL,
  `idgame` int(32) NOT NULL,
  `text` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_slovak_ci;

--
-- Kľúče pre exportované tabuľky
--

--
-- Indexy pre tabuľku `game`
--
ALTER TABLE `game`
  ADD PRIMARY KEY (`id`);

--
-- Indexy pre tabuľku `menu`
--
ALTER TABLE `menu`
  ADD PRIMARY KEY (`id`);

--
-- Indexy pre tabuľku `review`
--
ALTER TABLE `review`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT pre exportované tabuľky
--

--
-- AUTO_INCREMENT pre tabuľku `game`
--
ALTER TABLE `game`
  MODIFY `id` int(32) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT pre tabuľku `menu`
--
ALTER TABLE `menu`
  MODIFY `id` int(32) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pre tabuľku `review`
--
ALTER TABLE `review`
  MODIFY `id` int(32) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
